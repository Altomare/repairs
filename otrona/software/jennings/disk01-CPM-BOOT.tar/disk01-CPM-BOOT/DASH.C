
/*
	Make an Attache into a dashboard

*/

#define XMAX 319		/* dots across */
#define YMAX 239		/* dots up and down */

/*
	xX,xY		X,Y or gauge origin
	xF		gauge full scale value
	xM		gauge maximum (screen) value
	xC		gauge current displayed value
	xP		gauge pointer width

	Sx		Speedo
	Tx		Tach
	Fx		Fuel
	Wx		Water temp
	Px		Oil pressure
	Ox		Oil temp

*/

int s;			/* fake sensor values */

int sx,sy,sf,sm,sc,sp;		/* speedo */
int tx,ty,tf,tm,tc,tp;		/* tach */
int fx,fy,ff,fm,fc,fp;		/* fuel */
int wx,wy,wf,wm,wc,wp;		/* water temp */
int px,py,pf,pm,pc,pp;		/* oil pressure */
int ox,oy,of,om,oc,op;		/* oil temp */

int x,y;			/* G. P. drawing variables */
int t;				/* G. P. thickness */
int h,w;			/* G. P. hieght and width */
main() {

	printf("\033U \033S1");		/* set char size large, etc */
	printf("\0333");		/* clear and enable graphics */

	x = 0; y = 0; w = XMAX; h = YMAX; t = 1;
	box();				/* draw screen border */

/* Draw the two big sliders, speedometer and tachometer */

	x = 30; y = YMAX - 40; w = XMAX - 140; h = 14;
	t = 2;
	box();				/* speedo box */
	sx = x + t; sy = y + (h / 2);	/* speedo 0,0 location */
	sm = w - (2 * t);		/* dots full scale */
	sp = h;				/* indicator width */
	sf = 140;			/* 140 MPH full scale */
	sc = 0;				/* currently 0 MPH */

	y -= 40;			/* tach box location */
	box();
	tx = x + t; ty = y + (h / 2);
	tm = w - (2 * t);
	tf = 5000;
	tp = h;
	tc = 0;

/* Draw all the little gauges at the bottom */

	y= 70; x = 200; h = 60; w = 20;
	ff = 22; fm = h - (2 * t); fp = w; fy = y + t;
	wf = 250; wm = fm; wp = w; wy = y + t;
	pf = 80; pm = fm; pp = w; py = y + t;
	of = 400; om = fm; op = w; oy = y + t;

	box();				/* fuel box */
	x += 30; wx = x + (w / 2);
	box();				/* water temp */
	x += 30; px = x + (w / 2);
	box();				/* oil pressure */
	x += 30; ox = x + (w / 2);
	box();				/* oil temp */
}

/* Read the speedometer sensor, update the speedo display. */

speedo() {

int n;

	s = (++s % sf);			/* KLUDGE generate MPH */

	x= sx; y= sy - (sp / 2);	/* rectangle to fill */
	h = sp; w = sm / (sf / s);
	fill(1);

	x= sx + w; 			/* rectangle to clear */
	w= sm - w;
	fill(0);
}

/* Draw a box from X,Y to X + W and Y + H, thickness T. */

box() {

int i;

	for (i= 0; i <= t; i++) {
		plot(x - i,y - i);
		plotto(x - i,y + h + i);
		plotto(x + w + i,y + h + i);
		plotto(x + w + i,y - i);
		plotto(x - i,y - i);
	}
}

/* Plot a point at X, Y */

plot(x,y)
int x,y;
{
	printf("\0330");
	sga(x,y);
}

/* Plot from last plotted dot to X, Y */

plotto(x,y)
int x,y;
{
	printf("\0331");
	sga(x,y);
}
/* Fill and area from X,Y to X + W and Y + H, either white or black. */

fill(n)
int n;
{
	if (n) printf("\0335__");
	else printf("\0335  ");
	printf("\0334");
	sga(x,y);
	sga(x + w,y + h);
}

/* Send graphics args X and Y */

sga(x,y)
int x,y;
{	
	printf("%c%c%c%c",
		' ' + x / 32,
		' ' + x % 32,
		' ' + y / 32,
		' ' + y % 32);
/*
		'0' + (x >> 4) & 0x0f,	/* MS x, */
		'0' + x & 0x0f,		/* LS x, */
		'0' + (y >> 4) & 0x0f,	/* MS y, */
		'0' + y & 0x0f);	/* LS y */
*/
}
       